---
name: create skill
description: Tạo kỹ năng mới cho Claude Co-work (Skill Creator). Kích hoạt khi người dùng gõ "create skill", "tạo skill mới", "đóng gói quy trình", "tạo lệnh tùy chỉnh". Kể chuyện về quy trình lặp đi lặp lại → Claude đóng gói thành skill hoàn chỉnh sẵn dùng.
---

# 🛠️ Skill Creator — Tạo Kỹ Năng Mới

## Mục tiêu
Biến bất kỳ quy trình lặp đi lặp lại nào thành một Skill hoàn chỉnh. Chỉ cần kể về việc bạn thường làm → nhận được file SKILL.md sẵn sàng upload.

## Khi nào kích hoạt
- Người dùng gõ: `create skill`, `tạo skill mới`, `đóng gói quy trình`
- Người dùng nói: "tôi hay làm X mỗi ngày, muốn tạo lệnh tắt"
- Phù hợp cho: giáo viên, môi giới, marketer, designer, kế toán...

## Quy trình thực hiện

### Bước 1 — Phỏng vấn người dùng
Hỏi 5 câu hỏi vàng:

1. **Tên skill**: "Bạn muốn đặt từ khóa kích hoạt là gì? (VD: `baocao`, `email-khach`, `checklist`)"
2. **Mô tả**: "Skill này làm gì? Một câu ngắn gọn."
3. **Input**: "Claude cần thông tin gì để chạy skill này?"
4. **Output**: "Kết quả trả về là gì? (file, text, HTML, JSON...)"
5. **Ví dụ**: "Cho tôi xem 1 ví dụ cụ thể bạn hay làm?"

### Bước 2 — Phân tích quy trình
Từ ví dụ của người dùng, xác định:
- Các bước tuần tự (step 1, 2, 3...)
- Điều kiện rẽ nhánh (nếu A thì B, nếu C thì D)
- Connectors cần thiết (Gmail? Calendar? Slack?)
- Format output chuẩn

### Bước 3 — Tạo SKILL.md

```markdown
---
name: [từ khóa người dùng chọn]
description: [Mô tả rõ ràng khi nào kích hoạt và làm gì. 
Bao gồm: các từ khóa trigger, mục đích, output chính.]
---

# [Tên Skill]

## Mục tiêu
[1-2 câu mô tả mục tiêu]

## Khi nào kích hoạt
- [Từ khóa 1]
- [Từ khóa 2]
- [Ngữ cảnh kích hoạt]

## Input cần thiết
- [Input 1]
- [Input 2]

## Quy trình
### Bước 1 — [Tên bước]
[Hướng dẫn chi tiết]

### Bước 2 — [Tên bước]
[Hướng dẫn chi tiết]

## Output
[Mô tả output và cách lưu/chia sẻ]

## Ví dụ
[Ví dụ cụ thể input → output]
```

### Bước 4 — Review & Tinh chỉnh
- Hiển thị SKILL.md đã tạo
- Hỏi: "Skill này có đúng với quy trình của bạn chưa? Cần thêm/bớt gì không?"
- Chỉnh sửa theo feedback

### Bước 5 — Đóng gói & Hướng dẫn upload
Tạo thư mục `[tên-skill]/SKILL.md` và hướng dẫn:
> "Để cài skill này vào Co-work:
> 1. Vào Claude Co-work → Customize → Skills
> 2. Nhấn Upload → chọn thư mục `[tên-skill]`
> 3. Gõ `[từ khóa]` để test!"

## Ví dụ Skill có thể tạo
- **Giáo viên**: Skill tạo đề thi từ danh sách chủ đề
- **Môi giới BĐS**: Skill tạo email giới thiệu căn hộ
- **Marketer**: Skill tạo content calendar 1 tháng
- **Kế toán**: Skill tóm tắt báo cáo tài chính
- **HR**: Skill tạo JD (Job Description) chuẩn
