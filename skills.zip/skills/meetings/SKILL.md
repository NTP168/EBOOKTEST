---
name: meetings
description: Ghi chú và tóm tắt cuộc họp (Meeting Notes). Kích hoạt khi người dùng gõ "go meetings", "tóm tắt cuộc họp", "meeting notes", hoặc dán transcript cuộc họp vào. Tự động tạo tóm tắt sạch, danh sách hành động cụ thể, thời hạn và lưu file markdown.
---

# 📝 Meeting Notes Skill

## Mục tiêu
Biến transcript hoặc ghi chú thô của cuộc họp thành tài liệu chuyên nghiệp với action items rõ ràng. Cuộc họp 1 giờ → 10 bước hành động trong 30 giây.

## Khi nào kích hoạt
- Người dùng gõ: `go meetings`, `meeting notes`, `tóm tắt họp`
- Người dùng dán transcript/ghi chú cuộc họp
- Người dùng nói: "vừa họp xong, giúp tôi tóm tắt"

## Quy trình thực hiện

### Bước 1 — Thu thập input
Hỏi nếu chưa có:
- Transcript hoặc ghi chú thô của cuộc họp
- Ngày họp, tên cuộc họp
- Người tham dự (tùy chọn)

### Bước 2 — Phân tích & Tóm tắt
Đọc toàn bộ nội dung và xác định:
- 🎯 Mục tiêu cuộc họp là gì?
- ✅ Những gì đã được quyết định?
- ❌ Những gì còn chưa giải quyết?
- 👤 Ai chịu trách nhiệm việc gì?
- ⏰ Deadline của từng việc?

### Bước 3 — Tạo tài liệu

```markdown
# 📋 [Tên Cuộc Họp]
**Ngày:** [ngày] | **Thời gian:** [giờ] | **Người tham dự:** [danh sách]

---

## 🎯 Mục Tiêu Cuộc Họp
[1-2 câu mô tả mục tiêu]

## 📌 Tóm Tắt (3 điểm chính)
1. [Điểm quan trọng 1]
2. [Điểm quan trọng 2]  
3. [Điểm quan trọng 3]

## ✅ Quyết Định Đã Được Đưa Ra
- [Quyết định 1]
- [Quyết định 2]

## 🚀 Action Items
| # | Việc cần làm | Người phụ trách | Deadline |
|---|-------------|-----------------|----------|
| 1 | [Việc 1] | [Tên] | [Ngày] |
| 2 | [Việc 2] | [Tên] | [Ngày] |
| 3 | [Việc 3] | [Tên] | [Ngày] |

## ❓ Câu Hỏi Còn Mở / Cần Theo Dõi
- [Vấn đề 1 chưa giải quyết]
- [Vấn đề 2 cần làm rõ]

## 📅 Cuộc Họp Tiếp Theo
**Ngày:** [ngày nếu đã xác định] | **Chủ đề:** [chủ đề]
```

### Bước 4 — Lưu & Chia sẻ
- Lưu file: `outputs/meeting-[tên]-[ngày].md`
- Nếu có Slack: hỏi "Bạn có muốn gửi tóm tắt này lên Slack không?"
- Thông báo: "✅ Đã tóm tắt [X] action items từ cuộc họp!"

## Lưu ý
- Luôn highlight action items bằng emoji ✅
- Nếu không rõ ai phụ trách → ghi "TBD"
- Nếu không rõ deadline → ghi "Sớm nhất có thể"
- Giữ tóm tắt ngắn gọn, súc tích — không copy nguyên transcript
