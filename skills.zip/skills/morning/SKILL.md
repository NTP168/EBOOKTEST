---
name: morning
description: Tạo tin tức buổi sáng (Morning Briefing). Kích hoạt khi người dùng gõ "morning" hoặc "tin buổi sáng" hoặc "bắt đầu ngày mới". Tự động tổng hợp lịch, email, tin tức AI và tạo dashboard HTML đẹp với tất cả thông tin cần thiết cho ngày mới.
---

# 🌅 Morning Briefing Skill

## Mục tiêu
Tạo một trang HTML dashboard đẹp mỗi buổi sáng, tổng hợp tất cả thông tin bạn cần để bắt đầu ngày mới — chỉ từ một lệnh duy nhất.

## Khi nào kích hoạt
- Người dùng gõ: `morning`, `tin buổi sáng`, `bắt đầu ngày`, `briefing`

## Quy trình thực hiện

### Bước 1 — Thu thập thông tin
Nếu có Connectors, tự động lấy:
- 📅 **Google Calendar**: Lịch hôm nay và ngày mai
- 📧 **Gmail**: Email chưa đọc quan trọng (ưu tiên: starred, từ sếp/khách hàng)
- 🔗 **Slack**: Tin nhắn chưa đọc từ các channel quan trọng

Nếu không có Connectors, hỏi người dùng:
> "Hôm nay bạn có lịch gì không? Có email/tin nhắn quan trọng cần xử lý không?"

### Bước 2 — Lấy tin tức AI
Tìm kiếm web với query: `"AI news today"` hoặc `"tin tức AI hôm nay"`
Lọc lấy 3-5 tin nổi bật nhất.

### Bước 3 — Tạo HTML Dashboard
Tạo file `morning-[ngày].html` với:

```html
<!DOCTYPE html>
<html>
<!-- Dashboard với các section:
  1. Header: Ngày giờ + lời chào
  2. 🎯 Top 3 ưu tiên hôm nay
  3. 📅 Lịch hôm nay
  4. 📧 Email cần xử lý
  5. 💬 Tin nhắn Slack
  6. 🤖 Tin tức AI hôm nay
  7. 📝 Note nhanh
-->
</html>
```

**Yêu cầu thiết kế:**
- Nền tối (`#0a0a0f`), chữ sáng
- Màu vàng gold cho tiêu đề (`#C9A84C`)
- Card layout, responsive
- Font: system-ui hoặc Inter

### Bước 4 — Lưu & Gửi
- Lưu file HTML vào `outputs/morning-YYYY-MM-DD.html`
- Nếu có Slack connector: gửi link qua DM
- Thông báo: "✅ Morning briefing đã sẵn sàng!"

## Output mẫu
File HTML hoàn chỉnh có thể mở trực tiếp trên trình duyệt.

## Lưu ý
- Luôn hiển thị ngày/giờ hiện tại
- Nếu không có dữ liệu từ connector, dùng placeholder rõ ràng
- Giữ tone tích cực, energetic
